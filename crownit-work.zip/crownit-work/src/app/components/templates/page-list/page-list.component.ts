import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-page-list',
  templateUrl: './page-list.component.html',
  styleUrls: ['./page-list.component.css']
})
export class PageListComponent implements OnInit {



  @ViewChild('userTable') userTable: ElementRef | any;
  constructor(private http: HttpClient) { }

  ngOnInit(): void {

 
   


  }

}
